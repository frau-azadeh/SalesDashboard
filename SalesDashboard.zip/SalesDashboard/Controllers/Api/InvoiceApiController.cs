﻿using Microsoft.AspNetCore.Mvc;
using SalesDashboard.Data;
using SalesDashboard.Models;
using SalesDashboard.Models.Dto;

namespace SalesDashboard.Controllers.Api
{
    [ApiController]
    [Route("api/invoice")]
    public class InvoiceApiController : ControllerBase
    {
        private readonly AppDbContext _context;

        public InvoiceApiController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] InvoiceCreateDto model)
        {
            var username = "testuser"; // یا از Session بخون

            if (model == null || model.ProductIds == null || model.ProductIds.Count == 0)
                return BadRequest("❌ اطلاعات ناقص است.");

            var invoice = new Invoice
            {
                CustomerId = model.CustomerId,
                CreatedBy = username,
                Date = DateTime.Now,
                Items = new List<InvoiceItem>()
            };

            for (int i = 0; i < model.ProductIds.Count; i++)
            {
                var productId = model.ProductIds[i];
                var quantity = model.Quantities[i];

                var product = await _context.Products.FindAsync(productId);
                if (product == null)
                    return NotFound($"❌ محصول با شناسه {productId} یافت نشد.");

                if (product.Stock < quantity)
                    return BadRequest($"❌ موجودی کافی برای '{product.Name}' ندارید.");

                product.Stock -= quantity;

                invoice.Items.Add(new InvoiceItem
                {
                    ProductId = productId,
                    Quantity = quantity,
                    UnitPrice = product.Price
                });
            }

            await _context.Invoices.AddAsync(invoice);
            await _context.SaveChangesAsync();

            return Ok(new { message = "✅ فاکتور با موفقیت ثبت شد." });
        }
    }
}
