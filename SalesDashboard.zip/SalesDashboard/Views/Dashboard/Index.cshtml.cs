using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SalesDashboard.Views.Dashboard
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
