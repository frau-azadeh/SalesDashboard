using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SalesDashboard.Views.Invoice
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
