using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SalesDashboard.Views.Customers
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
