using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SalesDashboard.Views.Products
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
