using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SalesDashboard.Views.Shared
{
    public class _LoginStatusModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
